package digicompra;

/**
 *
 * @author floba
 */
public class digicompra {

    public static void main(String[] args) {

        // Crear instancia del CRUD
        Crud crud = new Crud();

        // INSERTAR
        crud.insertarDato(5, "jose", "789");

        // LEER
        crud.leerDatos();

        // ACTUALIZAR
        crud.actualizarDatos(3, "daniela", "Descripción actualizada");

        // ELIMINAR
        crud.eliminarDatos(5);

        // LEER NUEVAMENTE
        crud.leerDatos();
    }
}