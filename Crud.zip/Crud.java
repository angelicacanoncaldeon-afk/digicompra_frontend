package digicompra;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Crud {

    // INSERTAR datos en la tabla CATEGORIA
    public void insertarDato(int idCATEGORIA, String NOMBRE, String DESCRIPCION) {

        String query = "INSERT INTO CATEGORIA (idCATEGORIA, NOMBRE, DESCRIPCION) VALUES (?, ?, ?)";

        try (Connection con = dbConnection.conectar();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, idCATEGORIA);
            ps.setString(2, NOMBRE);
            ps.setString(3, DESCRIPCION);

            ps.executeUpdate();
            System.out.println("Datos insertados correctamente.");

        } catch (SQLException e) {
            System.out.println("Error al insertar datos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // LEER datos de la tabla CATEGORIA
    public void leerDatos() {

        String query = "SELECT * FROM CATEGORIA";

        try (Connection con = dbConnection.conectar();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int idCATEGORIA = rs.getInt("idCATEGORIA");
                String NOMBRE = rs.getString("NOMBRE");
                String DESCRIPCION = rs.getString("DESCRIPCION");

                System.out.println(
                        "IDCATEGORIA: " + idCATEGORIA +
                        " | NOMBRE: " + NOMBRE +
                        " | DESCRIPCION: " + DESCRIPCION
                );
            }

        } catch (SQLException e) {
            System.out.println("Error al leer datos: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ACTUALIZAR datos en la tabla CATEGORIA
    public void actualizarDatos(int idCATEGORIA, String NOMBRE, String DESCRIPCION) {

        String query = "UPDATE CATEGORIA SET NOMBRE = ?, DESCRIPCION = ? WHERE idCATEGORIA = ?";

        try (Connection con = dbConnection.conectar();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, NOMBRE);
            ps.setString(2, DESCRIPCION);
            ps.setInt(3, idCATEGORIA);

            ps.executeUpdate();
            System.out.println("Datos actualizados correctamente");

        } catch (SQLException e) {
            System.out.println("Error al actualizar datos");
            e.printStackTrace();
        }
    }

    // ELIMINAR datos de la tabla CATEGORIA
    public void eliminarDatos(int idCATEGORIA) {

        String query = "DELETE FROM CATEGORIA WHERE idCATEGORIA = ?";

        try (Connection con = dbConnection.conectar();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, idCATEGORIA);

            ps.executeUpdate();
            System.out.println("Registro eliminado correctamente");

        } catch (SQLException e) {
            System.out.println("Error al eliminar datos");
            e.printStackTrace();
        }
    }
}